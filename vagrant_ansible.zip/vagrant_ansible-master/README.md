# vagrant_ansible
vagrant_ansible test
